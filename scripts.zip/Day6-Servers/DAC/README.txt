DAC = Dynamic Access Control.

DAC was first available with Server 2012.

